## MAPA DE CIUDAD NOVA: el alcalde maneja el carro por las calles hasta cada lugar.
## La logica (grafo de calles, movimiento y rumbo) vive en clases/MapaCiudad.py;
## aqui solo se dibuja el mapa y se traduce el teclado a la direccion del carro.
## La historia usa el mapa para moverse: antes de cada escena llama a
## viajar_a_mision("id") y la escena empieza solo cuando el jugador llega al lugar.
## Fuera de esos viajes el mapa se puede abrir libremente desde el HUD.

default mapa_posicion = None
default ubicacion_actual = None
default mapa_objetivo = None

init python:
    import pygame
    from clases import Misiones as misiones
    from clases.MapaCiudad import (crear_mapa_nova, Carro, RUMBOS, UBICACIONES_FERIA,
                                   ANCHO_REF, ALTO_REF)

    MAPA_NOVA = crear_mapa_nova()
    MAPA_INICIO = "alcaldia"
    MAPA_IMAGEN = "images/bg/mapa.jpg"
    MAPA_ESCALA = 1920.0 / ANCHO_REF          # pixeles de pantalla por pixel de referencia
    MAPA_ZOOM_IMAGEN = 1920.0 / 3072.0
    MAPA_ZOOM_CARRO = 0.34
    MAPA_CAJA_CARRO = (120, 90)
    MAPA_CARPETA_CARRO = "images/personajes/Sprites_carro/Carro_%s/%d.png"
    MAPA_CUADROS_POR_SEGUNDO = 9

    # id -> (nombre, descripcion, centro del rotulo en el mapa de referencia)
    UBICACIONES = {
        "centro": ("Centro", "La plaza donde todo se comenta.", (1000, 413)),
        "alcaldia": ("Alcaldía", "Tu despacho y el centro de operaciones.", (1285, 698)),
        "prensa": ("Prensa", "Las redacciones de Ciudad Nova.", (1370, 240)),
        "barrio_sur": ("Barrio Sur", "Donde los rumores corren más rápido.", (980, 1080)),
        "universidad": ("Universidad", "Aulas, estudiantes y mucho debate.", (775, 180)),
        "barrio_norte": ("Barrio Norte", "Casas, vecinos y grupos de chat.", (360, 410)),
        "parque": ("Parque Central", "El lago y la gente de siempre.", (420, 838)),
        "transporte": ("Transporte Público", "Todos pasan por aquí cada día.", (1580, 994)),
    }

    # Radio (px de referencia) a menos del cual se considera que el carro llego a un lugar.
    MAPA_RADIO_LLEGADA = 70.0

    def mision_actual():
        return misiones.mision_activa(store.misiones_hechas, store.modo_feria_activo)

    def mision_destino():
        """La mision que se esta viajando; si no hay viaje, la siguiente de la historia."""
        if store.mapa_objetivo in misiones.POR_ID:
            return misiones.POR_ID[store.mapa_objetivo]
        return mision_actual()

    def abrir_mapa_libre():
        if renpy.get_screen("mapa_viaje") is None:
            renpy.show_screen("mapa_ciudad")

    def mapa_ya_en(ubicacion):
        carro = Carro(MAPA_NOVA, MAPA_INICIO)
        if store.mapa_posicion:
            carro.restaurar(store.mapa_posicion)
        return carro.ubicacion_cercana(MAPA_RADIO_LLEGADA) == ubicacion

    def mapa_debe_conducir(mision_id):
        """En el Modo Feria solo se conducen algunos viajes; tampoco hace falta si ya se esta en el lugar."""
        if store.modo_feria_activo and mision_id not in misiones.FERIA_CONDUCIR:
            return False
        return not mapa_ya_en(misiones.POR_ID[mision_id]["ubicacion"])

    def mapa_llegar_directo(ubicacion):
        nodo = MAPA_NOVA.paradas[ubicacion]
        store.mapa_posicion = {"origen": nodo, "destino": nodo, "avance": 0.0}

    def ubicacion_disponible(ubicacion):
        return (not store.modo_feria_activo) or ubicacion in UBICACIONES_FERIA

    def entrar_ubicacion(ubicacion):
        """Gancho de llegada: hoy solo guarda el lugar y avisa."""
        if not ubicacion_disponible(ubicacion):
            return
        store.ubicacion_actual = ubicacion
        sonar("assets/audio/sfx/ui_click.wav")
        mision = mision_actual()
        if mision and mision["ubicacion"] == ubicacion:
            renpy.notify("Llegaste a %s. Aquí transcurre: %s" % (UBICACIONES[ubicacion][0], mision["titulo"]))
        else:
            renpy.notify("Llegaste a %s" % UBICACIONES[ubicacion][0])

    def cargar_cuadros_carro():
        cuadros = {}
        for rumbo in RUMBOS:
            lista, i = [], 0
            while renpy.loadable(MAPA_CARPETA_CARRO % (rumbo, i)):
                imagen = Transform(MAPA_CARPETA_CARRO % (rumbo, i), zoom=MAPA_ZOOM_CARRO, align=(0.5, 0.5))
                lista.append(Fixed(imagen, xysize=MAPA_CAJA_CARRO))
                i += 1
            cuadros[rumbo] = lista
        return cuadros

    class MapaConduccion(renpy.Displayable):
        """El mapa ilustrado con el carro encima. Flechas, WASD o mando conducen; Enter o A entra al lugar."""

        def __init__(self, obligatorio=False, destino=None, **kwargs):
            super(MapaConduccion, self).__init__(**kwargs)
            self.obligatorio = obligatorio
            self.destino = destino
            self.carro = Carro(MAPA_NOVA, MAPA_INICIO)
            if store.mapa_posicion:
                self.carro.restaurar(store.mapa_posicion)
            self.fondo = Transform(MAPA_IMAGEN, zoom=MAPA_ZOOM_IMAGEN)
            self.cuadros = cargar_cuadros_carro()
            self.sombra = Solid("#0000004d")
            self.pulsadas = []
            self.pulso = None  # (vector, segundos): un toque en las flechas tactiles conduce un momento
            self.previo = None
            self.camara = None
            self.cerca = self.carro.ubicacion_cercana()
            self.cerca_avisada = self.cerca
            self.depurar = False

        def guardar(self):
            store.mapa_posicion = self.carro.estado()

        # ----- dibujo -----

        def direccion(self):
            dx = dy = 0
            for _nombre, (ax, ay) in self.pulsadas:
                dx, dy = (ax or dx), (ay or dy)
            if self.pulso and not (dx or dy):
                dx, dy = self.pulso[0]
            return dx, dy

        def empujar(self, dx, dy):
            self.pulso = [(dx, dy), 0.6]
            renpy.redraw(self, 0)

        def tocar_accion(self):
            """Boton tactil equivalente a Enter / A."""
            if not self.cerca:
                return None
            if self.obligatorio:
                if self.cerca == self.destino:
                    self.guardar()
                    return "llegada"
                mision = mision_destino()
                if mision:
                    renpy.notify("Aquí todavía no pasa nada. Tu misión: %s, en %s." % (
                        mision["titulo"], UBICACIONES[mision["ubicacion"]][0]))
                return None
            entrar_ubicacion(self.cerca)
            return None

        def render(self, width, height, st, at):
            dt = 0.0 if self.previo is None else min(0.05, st - self.previo)
            self.previo = st
            if self.pulso:
                self.pulso[1] -= dt
                if self.pulso[1] <= 0:
                    self.pulso = None
            dx, dy = self.direccion()
            self.carro.avanzar(dt, dx, dy)
            self.cerca = self.carro.ubicacion_cercana()
            if self.cerca != self.cerca_avisada:
                # Conduciendo con las flechas tactiles no hay eventos: el boton LLEGAR debe actualizarse igual.
                self.cerca_avisada = self.cerca
                renpy.restart_interaction()

            x, y = self.carro.posicion()
            objetivo = max(0.0, min(y * MAPA_ESCALA - height / 2.0, ALTO_REF * MAPA_ESCALA - height))
            if self.camara is None:
                self.camara = objetivo
            self.camara += (objetivo - self.camara) * min(1.0, dt * 5.0)

            r = renpy.Render(width, height)
            r.blit(renpy.render(self.fondo, width, height, st, at), (0, -int(self.camara)))
            self.dibujar_apagadas(r)
            self.dibujar_destino(r, st, width, height)
            if self.depurar:
                self.dibujar_calles(r)

            px, py = x * MAPA_ESCALA, y * MAPA_ESCALA - self.camara
            cuadros = self.cuadros[self.carro.rumbo]
            if cuadros:
                indice = int(st * MAPA_CUADROS_POR_SEGUNDO) % len(cuadros) if self.carro.velocidad > 1.0 else 0
                cw, ch = MAPA_CAJA_CARRO
                r.blit(renpy.render(self.sombra, 70, 18, st, at), (int(px - 35), int(py + 6)))
                r.blit(renpy.render(cuadros[indice], cw, ch, st, at), (int(px - cw / 2), int(py - ch * 0.62)))
            renpy.redraw(self, 0)
            return r

        def dibujar_apagadas(self, r):
            """En el Modo Feria los lugares fuera de la feria se ven atenuados."""
            lienzo = r.canvas()
            for ubicacion, (nombre, descripcion, centro) in UBICACIONES.items():
                if not ubicacion_disponible(ubicacion):
                    cx, cy = centro[0] * MAPA_ESCALA, centro[1] * MAPA_ESCALA - self.camara
                    lienzo.rect((18, 13, 28, 175), (int(cx - 140), int(cy - 34), 280, 68))

        def dibujar_destino(self, r, st, width, height):
            """Aro pulsante sobre el lugar de la mision activa; si esta fuera de pantalla, una flecha en el borde."""
            mision = mision_destino()
            if not mision or mision["ubicacion"] not in MAPA_NOVA.paradas:
                return
            sx, sy = MAPA_NOVA.pos[MAPA_NOVA.paradas[mision["ubicacion"]]]
            cx, cy = sx * MAPA_ESCALA, sy * MAPA_ESCALA - self.camara
            lienzo = r.canvas()
            if 90 <= cy <= height - 20:
                pulso = (st * 1.6) % 1.0
                lienzo.circle((250, 204, 21, int(230 * (1.0 - pulso))), (int(cx), int(cy)), int(26 + 46 * pulso), 4)
                lienzo.circle((250, 204, 21, 255), (int(cx), int(cy)), 11)
                lienzo.circle((18, 13, 28, 255), (int(cx), int(cy)), 11, 3)
                lienzo.polygon((250, 204, 21, 255), [(cx - 14, cy - 58), (cx + 14, cy - 58), (cx, cy - 34)])
            else:
                arriba = cy < 90
                y = 110 if arriba else height - 40
                dy = -16 if arriba else 16
                x = max(40, min(width - 40, cx))
                lienzo.polygon((250, 204, 21, 255), [(x - 18, y - dy), (x + 18, y - dy), (x, y + dy)])

        def dibujar_calles(self, r):
            lienzo = r.canvas()
            for a, b in MAPA_NOVA.aristas():
                (xa, ya), (xb, yb) = MAPA_NOVA.pos[a], MAPA_NOVA.pos[b]
                lienzo.line((255, 60, 60, 255), (xa * MAPA_ESCALA, ya * MAPA_ESCALA - self.camara),
                            (xb * MAPA_ESCALA, yb * MAPA_ESCALA - self.camara), 3)
            for nodo, (nx, ny) in MAPA_NOVA.pos.items():
                color = (60, 255, 90, 255) if MAPA_NOVA.ubicacion_de_nodo(nodo) else (255, 230, 60, 255)
                lienzo.circle(color, (int(nx * MAPA_ESCALA), int(ny * MAPA_ESCALA - self.camara)), 6)

        # ----- entrada -----

        def event(self, ev, x, y, st):
            direccion = direccion_evento(ev)
            if direccion is not None:
                nombre, vector, pulsada = direccion
                self.pulsadas = [p for p in self.pulsadas if p[0] != nombre]
                if pulsada:
                    self.pulsadas.append((nombre, vector))
                raise renpy.IgnoreEvent()
            if renpy.map_event(ev, "civ_accion"):
                if self.cerca and self.obligatorio:
                    return self.llegar(self.cerca)
                if self.cerca:
                    entrar_ubicacion(self.cerca)
                raise renpy.IgnoreEvent()
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_F9 and config.developer:
                self.depurar = not self.depurar
                raise renpy.IgnoreEvent()
            if self.cerca != self.cerca_avisada:
                self.cerca_avisada = self.cerca
                renpy.restart_interaction()
            return None

        def llegar(self, ubicacion):
            """Viaje obligatorio: solo el lugar de la mision termina la interaccion."""
            if ubicacion == self.destino:
                self.guardar()
                sonar("assets/audio/sfx/ui_click.wav")
                return "llegada"
            mision = mision_destino()
            if mision:
                renpy.notify("Aquí todavía no pasa nada. Tu misión: %s, en %s." % (
                    mision["titulo"], UBICACIONES[mision["ubicacion"]][0]))
            raise renpy.IgnoreEvent()

        def visit(self):
            return [self.fondo]


style mapa_texto is default:
    color "#fbf6ee"

## Remaster 3: los paneles del mapa son fichas de papel con contorno de tinta (como el HUD y CivitasNet).
init python:
    def mapa_ficha(franja=None):
        return Frame(ficha_fondo(240, 140, franja=franja, franja_w=12, sombra=8, borde=3), 26, 20, 26, 28)

screen mapa_ciudad():
    zorder 103
    modal True
    default vista = MapaConduccion()
    on "hide" action Function(vista.guardar)
    key "game_menu" action Hide("mapa_ciudad")

    add vista
    use mapa_cuerpo(vista, False)

## Viaje de la historia: debajo del HUD (zorder 50) para poder consultar pistas, y sin boton de volver.
screen mapa_viaje(destino):
    zorder 40
    modal True
    default vista = MapaConduccion(obligatorio=True, destino=destino)

    add vista
    use mapa_cuerpo(vista, True)

default persistent.controles_tactiles = False

screen mapa_tactil(vista, obligatorio):
    ## Telefono o tableta: flechas (cada toque conduce un momento), entrar e ir directo.
    fixed:
        xpos 40
        yalign 0.62
        xysize (330, 330)
        for giro, (dx, dy), posicion in ((0, (0, -1), (110, 0)), (180, (0, 1), (110, 220)),
                                         (270, (-1, 0), (0, 110)), (90, (1, 0), (220, 110))):
            button:
                pos posicion
                xysize (110, 110)
                background Frame("gui/telefono_boton.png", 30, 30)
                hover_background Frame("gui/telefono_boton_hover.png", 30, 30)
                action Function(vista.empujar, dx, dy)
                add Transform("gui/flecha_tactil.png", rotate=giro, rotate_pad=False) align (0.5, 0.5)
    vbox:
        xalign 0.97
        yalign 0.92
        spacing 16
        textbutton ("LLEGAR" if obligatorio else "ENTRAR"):
            xsize 300
            ysize 100
            background Frame("gui/telefono_boton.png", 30, 30)
            hover_background Frame("gui/telefono_boton_hover.png", 30, 30)
            text_size 34
            text_bold True
            text_color "#fbf6ee"
            text_insensitive_color "#8b84a8"
            text_xalign 0.5
            text_yalign 0.5
            sensitive vista.cerca is not None
            action Function(vista.tocar_accion)
        if obligatorio and vista.destino:
            textbutton "Ir directo":
                xsize 300
                ysize 80
                background Frame("gui/telefono_boton.png", 30, 30)
                hover_background Frame("gui/telefono_boton_hover.png", 30, 30)
                text_size 26
                text_color "#fbf6ee"
                text_xalign 0.5
                text_yalign 0.5
                action [Function(mapa_llegar_directo, vista.destino), Return("llegada")]

screen mapa_cuerpo(vista, obligatorio):
    if renpy.variant("touch") or persistent.controles_tactiles:
        use mapa_tactil(vista, obligatorio)
    ## Barra superior
    frame:
        xfill True
        ysize 76
        padding (40, 10, 40, 10)
        background Fixed(Solid("#120d1ceb"), Solid("#d1495b", xysize=(1920, 4), ypos=72))
        hbox:
            xfill True
            yalign 0.5
            hbox:
                yalign 0.5
                spacing 18
                text "MAPA" size 15 bold True color "#c9b8d8" kerning 4 yalign 0.5
                text "Ciudad Nova" font CIV_FUENTE_FINA size 40 style "mapa_texto" yalign 0.5
            if not obligatorio:
                hbox:
                    xalign 1.0
                    yalign 0.5
                    use civ_cerrar(Hide("mapa_ciudad"), "VOLVER")

    ## Mision activa
    $ mision = mision_destino()
    $ destino_nombre = UBICACIONES[mision["ubicacion"]][0] if mision else ""
    frame:
        xalign 1.0
        xoffset -36
        ypos 100
        xsize 540
        padding (40, 20, 28, 30)
        background mapa_ficha("#e8b04b")
        vbox:
            spacing 6
            text ("VIAJE · MISIÓN PRINCIPAL" if obligatorio else "MISIÓN PRINCIPAL") size 14 bold True color "#b07a1c" kerning 3
            if mision:
                text mision["titulo"] font CIV_FUENTE_FINA size 34 color "#2b2440"
                text mision["descripcion"] size 18 color "#5b4f72"
                null height 6
                frame:
                    background Solid("#2b2440")
                    padding (10, 3)
                    text "Destino: [destino_nombre]" size 16 bold True color "#fbf6ee"
            else:
                text "Sin misiones pendientes" font CIV_FUENTE_FINA size 32 color "#2b2440"
                text "Explora la ciudad cuando quieras." size 18 color "#5b4f72"

    ## Controles
    frame:
        xpos 40
        yalign 1.0
        yoffset -40
        padding (26, 16, 26, 26)
        background mapa_ficha()
        vbox:
            spacing 6
            text "CONTROLES" size 14 bold True color "#8c2f4b" kerning 4
            text "Flechas, WASD o cruceta: conducir" size 19 color "#2b2440"
            text ("Enter o A: llegar al destino" if obligatorio else "Enter o A: entrar al lugar") size 19 color "#2b2440"
            text ("Esc: menú" if obligatorio else "Esc: volver") size 19 color "#2b2440"

    ## Tarjeta del lugar cercano
    if vista.cerca:
        $ nombre_lugar, texto_lugar, _centro = UBICACIONES[vista.cerca]
        $ disponible = ubicacion_disponible(vista.cerca)
        $ es_destino = disponible and mision and mision["ubicacion"] == vista.cerca
        frame:
            xalign 0.5
            yalign 1.0
            yoffset -40
            xsize 660
            padding (40, 18, 28, 30)
            background mapa_ficha("#e8b04b" if es_destino else ("#d1495b" if not disponible else "#c9b8d8"))
            vbox:
                spacing 4
                xalign 0.5
                text nombre_lugar font CIV_FUENTE_FINA size 42 color "#2b2440" xalign 0.5
                text texto_lugar size 19 color "#5b4f72" xalign 0.5
                null height 8
                if es_destino:
                    frame:
                        xalign 0.5
                        background Solid("#2b2440")
                        padding (14, 4)
                        text "Es el destino de tu misión · Pulsa Enter o A" size 18 bold True color "#e8b04b"
                elif obligatorio:
                    text "Aquí no pasa nada por ahora" size 18 bold True color "#8b84a8" xalign 0.5
                elif disponible:
                    text "Pulsa Enter o A para entrar" size 18 bold True color "#8c2f4b" xalign 0.5
                else:
                    text "No disponible en el Modo Feria" size 18 bold True color "#d1495b" xalign 0.5


## La historia llama a este label antes de cada escena que ocurre en un lugar del mapa.
## Si el carro ya esta ahi (o la feria no pide conducir ese tramo) llega directo.
label viajar_a_mision(mision_id):
    $ mapa_objetivo = mision_id
    $ lugar_viaje = misiones.POR_ID[mision_id]["ubicacion"]
    if mapa_debe_conducir(mision_id):
        $ ocultar_avisos_juego()
        show screen hud_ciudad
        window hide
        $ quick_menu_previo = quick_menu
        $ quick_menu = False
        $ renpy.notify("Nueva misión: %s" % misiones.POR_ID[mision_id]["titulo"])
        call screen mapa_viaje(lugar_viaje)
        $ quick_menu = quick_menu_previo
        window auto
    else:
        $ mapa_llegar_directo(lugar_viaje)
    $ ubicacion_actual = lugar_viaje
    $ mapa_objetivo = None
    return
