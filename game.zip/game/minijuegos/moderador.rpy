## Minijuego 2 - Moderador (tiempo real).
## Uso:  call minijuego_moderador             (semilla aleatoria)
##       call minijuego_moderador(semilla=7)  (partida reproducible)

init python:
    from clases.Moderador import ColaModeracion
    from clases.Publicacion import Publicacion

    from clases.moderacion_datos import COMENTARIOS_MODERACION, publicaciones_moderacion


    def avatar_comentario(autor):
        if red_civitas.existe(autor):
            return icono_aparente(red_civitas, autor, False)
        return ICONO_TIPO["ciudadano"]

    def moderacion_salida(cola):
        if cola.historial:
            com, eliminar, correcto = cola.historial[-1]
            renpy.hide_screen("moderador_salida")
            renpy.show_screen("moderador_salida", autor=com.autor, contenido=com.contenido, borrado=eliminar, correcto=correcto)

    def tick_moderacion(cola, dt):
        atendidas = cola.atendidas
        cola.tick(dt)
        if cola.atendidas != atendidas and cola.ultimo:
            moderacion_salida(cola)
            sonar(SONIDO_AVISO["bueno" if cola.ultimo[1] else "malo"])
            renpy.hide_screen("moderador_feedback")
            renpy.show_screen("moderador_feedback", texto=cola.ultimo[0], correcto=cola.ultimo[1])
            if cola.terminado():
                sonar(SONIDO_EXITO if cola.exito() else SONIDO_FALLO)

    def moderar(cola, eliminar):
        antes = cola.atendidas
        ok = cola.decidir(eliminar)
        if cola.atendidas != antes:
            moderacion_salida(cola)
        if ok:
            sonar(SONIDO_AVISO["bueno"])
        else:
            sonar(SONIDO_AVISO["malo"])
        if cola.terminado():
            sonar(SONIDO_EXITO if cola.exito() else SONIDO_FALLO)
        renpy.hide_screen("moderador_feedback")
        renpy.show_screen("moderador_feedback", texto=cola.ultimo[0], correcto=cola.ultimo[1])


transform tarjeta_comentario:
    alpha 0.0 yoffset (0 if persistent.reducir_movimiento else 40)
    easein 0.22 alpha 1.0 yoffset 0

transform sello_girado:
    rotate -8

transform tarjeta_sale(lado):
    alpha 1.0 xoffset 0 rotate 0
    easein 0.38 alpha 0.0 xoffset (0 if persistent.reducir_movimiento else lado * 760) rotate (0 if persistent.reducir_movimiento else lado * 9)

transform feedback_moderador:
    alpha 0.0 zoom 1.4
    easein 0.15 alpha 1.0 zoom 1.0
    pause 0.45
    easeout 0.3 alpha 0.0 yoffset -30

screen moderador_feedback(texto, correcto):
    zorder 120
    text texto at feedback_moderador:
        xalign 0.5
        ypos 300
        size 44
        bold True
        color ("#2f9e8f" if correcto else "#e04f5f")
        outlines [(4, "#fbf6ee", 0, 0)]
    timer 0.95 action Hide("moderador_feedback")

## Remaster: el comentario como publicacion de CivitasNet (papel, contorno de tinta, franja y contexto).
screen moderador_ficha(autor, creada, contenido, franja="#c9b8d8", sello=None, sello_color="#2b2440"):
    fixed:
        xysize (1000, 300)
        add Solid("#2b2440")
        add Solid("#fbf6ee", xysize=(988, 288), pos=(6, 6))
        add Solid(franja, xysize=(12, 288), pos=(6, 6))
        hbox:
            pos (46, 34)
            spacing 18
            add Transform(avatar_comentario(autor), xysize=(78, 78))
            vbox:
                yalign 0.5
                text autor size 28 bold True color "#2b2440"
                text ("Cuenta creada: " + creada + "  ·  " if creada else "") + "comentario reportado" size 17 color "#8b84a8"
        text contenido size 30 color "#2b2440" pos (46, 138) xmaximum 900
        if sello:
            text sello size 46 bold True color sello_color pos (640, 190) outlines [(4, "#fbf6ee", 0, 0)] at sello_girado

screen moderador_tarjeta(cola, creadas):
    $ com = cola.actual
    fixed:
        xalign 0.5
        ypos 380
        xysize (1000, 300)
        use moderador_ficha(com.autor, creadas.get(com.autor, "?"), com.contenido)

screen moderador_salida(autor, contenido, borrado, correcto):
    zorder 41
    fixed at tarjeta_sale(-1 if borrado else 1):
        xalign 0.5
        ypos 380
        xysize (1000, 300)
        use moderador_ficha(autor, "", contenido, ("#d1495b" if borrado else "#2f9e8f"),
                            ("BORRADO" if borrado else "APROBADO"), ("#d1495b" if borrado else "#2f9e8f"))
    timer 0.45 action Hide("moderador_salida")

screen moderador_ui(cola, creadas):
    modal True
    zorder 40

    if not cola.terminado():
        timer 0.05 repeat True action If(minijuego_pausado, NullAction(), Function(tick_moderacion, cola, 0.05))
        use boton_pausa_minijuego
        if cola.jugando():
            key "civ_izq" action Function(moderar, cola, True)
            key "civ_der" action Function(moderar, cola, False)

    add "bg civitas"
    add Solid("#1b1426b0")

    vbox:
        xpos 80
        ypos 40
        text "MODERACIÓN EXPRESS" size 40 bold True color "#fbf6ee"
        text "Borra bots y desinformación. Aprueba a las personas reales, aunque critiquen." size 20 color "#c9b8d8"
    hbox:
        xalign 0.96
        ypos 40
        spacing 60
        vbox:
            text "PUNTOS" size 16 color "#c9b8d8"
            text formato_num(cola.puntos) size 38 bold True color "#fbf6ee"
        vbox:
            text "VIDAS" size 16 color "#c9b8d8"
            hbox:
                spacing 8
                for i in range(3):
                    add circulo("#d1495b" if i < cola.vidas else "#3a3350", "#fbf6ee", 14)
        vbox:
            text "EN COLA" size 16 color "#c9b8d8"
            text "[cola.pendientes()]" size 38 bold True color "#fbf6ee"

    if cola.racha >= 3:
        text "RACHA x[cola.racha]" size 34 bold True color "#e8b04b" xalign 0.5 ypos 170 outlines [(3, "#2b2440", 0, 0)]

    # Al terminar se retiran tarjeta y botones: si no, el mando puede quedarse con el foco en BORRAR/APROBAR.
    if cola.actual is not None and cola.intro <= 0 and not cola.terminado():
        add Solid("#2b2440", xysize=(1000, 26)) xalign 0.5 ypos 325
        bar:
            xalign 0.5
            ypos 330
            xsize 988
            ysize 16
            value StaticValue(cola.progreso_tiempo(), 1.0)
            left_bar Solid("#d1495b" if cola.progreso_tiempo() < 0.35 else "#c9b8d8")
            right_bar Solid("#3a3350")
        if cola.atendidas % 2 == 0:
            fixed at tarjeta_comentario:
                use moderador_tarjeta(cola, creadas)
        else:
            fixed at tarjeta_comentario:
                use moderador_tarjeta(cola, creadas)

        hbox:
            xalign 0.5
            ypos 820
            spacing 60
            textbutton "<  BORRAR":
                xsize 400
                ysize 90
                background Frame(Fixed(Solid("#2b2440"), Solid("#fbf6ee", xysize=(394, 84), pos=(3, 3)), Solid("#d1495b", xysize=(12, 84), pos=(3, 3)), xysize=(400, 90)), 16, 8)
                hover_background Frame(Fixed(Solid("#2b2440"), Solid("#d1495b", xysize=(394, 84), pos=(3, 3)), xysize=(400, 90)), 16, 8)
                text_size 30
                text_bold True
                text_color "#2b2440"
                text_hover_color "#fbf6ee"
                text_xalign 0.5
                text_yalign 0.5
                hover_sound "assets/audio/sfx/menu_hover.ogg"
                action Function(moderar, cola, True)
            textbutton "APROBAR  >":
                xsize 400
                ysize 90
                background Frame(Fixed(Solid("#2b2440"), Solid("#fbf6ee", xysize=(394, 84), pos=(3, 3)), Solid("#2f9e8f", xysize=(12, 84), pos=(3, 3)), xysize=(400, 90)), 16, 8)
                hover_background Frame(Fixed(Solid("#2b2440"), Solid("#2f9e8f", xysize=(394, 84), pos=(3, 3)), xysize=(400, 90)), 16, 8)
                text_size 30
                text_bold True
                text_color "#2b2440"
                text_hover_color "#fbf6ee"
                text_xalign 0.5
                text_yalign 0.5
                hover_sound "assets/audio/sfx/menu_hover.ogg"
                action Function(moderar, cola, False)

    if cola.intro > 0:
        add Solid("#000000a0")
        vbox:
            align (0.5, 0.45)
            spacing 20
            text moderacion_intro size 36 color "#fbf6ee" xalign 0.5
            text "Borrar: flecha izquierda, tecla A o cruceta izquierda     Aprobar: flecha derecha, tecla D o cruceta derecha" size 26 bold True color "#e8b04b" xalign 0.5
            text "Ojo: criticar al alcalde no es desinformación." size 28 color "#c9b8d8" xalign 0.5
            text "%d" % (int(cola.intro) + 1) size 140 bold True color "#ffffff" xalign 0.5

    if cola.terminado():
        use resultado_tarjeta(cola.exito(), ("¡COMENTARIOS LIMPIOS!" if cola.exito() else "LOS BOTS GANARON ESTA VEZ"), None,
                              "Aciertos: %d   Errores: %d   Mejor racha: x%d" % (cola.aciertos, cola.errores, cola.mejor_racha),
                              [("PUNTOS", formato_num(cola.puntos), "#8c2f4b"), ("ACIERTOS", "%d" % cola.aciertos, "#2b2440"),
                               ("ERRORES", "%d" % cola.errores, "#d1495b" if cola.errores else "#2b2440"), ("MEJOR RACHA", "x%d" % cola.mejor_racha, "#2b2440")])
        key "civ_accion" action Return()


default moderacion_intro = "Los comentarios de Martina están llenos de bots."

label minijuego_moderador(semilla=None, aplicar=True, cantidad=16):
    $ semilla_moderacion = semilla if semilla is not None else renpy.random.randint(1, 999999)
    $ comentarios_mod, creadas_mod = publicaciones_moderacion(semilla_moderacion, cantidad)
    $ moderacion = ColaModeracion(comentarios_mod)
    $ hud_estaba_visible = renpy.get_screen("hud_ciudad") is not None
    $ ocultar_avisos_juego()
    hide screen hud_ciudad
    window hide
    $ renpy.block_rollback()
    call screen moderador_ui(moderacion, creadas_mod)
    hide screen moderador_feedback
    if hud_estaba_visible:
        show screen hud_ciudad
    $ resultado_minijuego = registrar_minijuego(moderacion.resultado(), aplicar)
    $ renpy.block_rollback()
    return resultado_minijuego
